"""Create a minimal Hugging Face Docker Space ZIP for the AI Clip Studio backend."""

from __future__ import annotations

from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "ai-clip-studio-hf-docker-space.zip"
REQUIRED_FILES = ("Dockerfile", "README.md", ".dockerignore")
SECRET_NAMES = {".env", ".env.local", "secrets.toml", "credentials.json"}
SECRET_MARKERS = ("secret", "credential", "password", "token", "private_key")


def main() -> None:
    missing = [name for name in REQUIRED_FILES if not (ROOT / name).is_file()]
    if missing:
        raise SystemExit(f"Required deployment files are missing: {', '.join(missing)}")

    backend_files = sorted(path for path in (ROOT / "backend").rglob("*") if path.is_file())
    if not backend_files:
        raise SystemExit("No backend files found.")

    files = [ROOT / name for name in REQUIRED_FILES] + backend_files
    with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            relative = path.relative_to(ROOT)
            if any(
                part in SECRET_NAMES or any(marker in part.lower() for marker in SECRET_MARKERS)
                for part in relative.parts
            ):
                continue
            if path.name.endswith((".pyc", ".pyo")) or "__pycache__" in relative.parts:
                continue
            archive.write(path, arcname=relative.as_posix())

    print(f"Created: {OUTPUT}")
    print("Included: Dockerfile, README.md, .dockerignore, and backend/ only.")


if __name__ == "__main__":
    main()
