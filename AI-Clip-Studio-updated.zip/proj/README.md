---
sdk: docker
app_port: 7860
---

# AI Clip Studio processing backend

Docker Space configuration for the separate AI Clip Studio video-processing API. This does not deploy or change the Flet app.

## Create the Space

1. In Hugging Face, create a new **Space** and choose **Docker** as its SDK.
2. Keep it private while setting it up. Do not add paid hardware or persistent storage.
3. Add `AI_API_TOKEN` in the Space's **Settings → Variables and secrets** as a secret. Use a long, random value and keep it private. Do not put it in this repository or in the Flet app.
4. Wait for the Space to build. The API listens on port `7860`; check `/health` and `/ready` on the Space URL.

## Free-tier limits to know

This image uses CPU-only processing. Building the image and running PyTorch, Faster-Whisper, OpenCV, FFmpeg, and Silero VAD may exceed free build or runtime resources; this has not been tested on Hugging Face Spaces. Free Space storage is temporary: jobs, uploaded videos, generated clips, the SQLite database, and downloaded model files can disappear when the Space restarts or sleeps. Persistent storage is not enabled by this repository and may require a paid option. Do not use this as dependable long-term storage.

The app currently does not upload to this API. `/docs` can be used for a direct manual API test after the Space is ready. Processing a video has not been verified.

## Configuration

- Required secret: `AI_API_TOKEN`.
- Optional variable: `ALLOWED_ORIGINS` (comma-separated exact browser origins, only needed when a browser-based client is connected).
- The Dockerfile sets the 100 MB upload cap, one CPU worker, tiny Whisper model, and storage/cache directories under `/data`.
- Do not set an API token in a Docker build argument or commit it to files.
