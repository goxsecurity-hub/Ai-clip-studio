"""ASGI API for authorized video-highlight jobs.

Run behind HTTPS, with a persistent AI_STORAGE_DIR and one worker process.
"""

from __future__ import annotations

import asyncio
import hmac
import logging
import os
import shutil
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Form, Header, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

import job_store

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("ai_clip_backend")

STORAGE_DIR = Path(os.getenv("AI_STORAGE_DIR", "./ai_storage")).resolve()
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_BYTES", "100000000"))  # 100 MB (decimal)
ALLOWED_EXTENSIONS = {".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi"}

app = FastAPI(title="AI Clip Studio Processing API", version="0.2.0")
origins = [item.strip() for item in os.getenv("ALLOWED_ORIGINS", "").split(",") if item.strip()]
if origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=False,
        allow_methods=["GET", "POST"],
        allow_headers=["Authorization", "Content-Type"],
    )


@app.on_event("startup")
async def startup() -> None:
    await asyncio.to_thread(job_store.initialize)


def _authorize(authorization: str | None) -> None:
    configured = os.getenv("AI_API_TOKEN")
    if not configured:
        raise HTTPException(status_code=503, detail="Backend is not configured: AI_API_TOKEN is missing.")
    supplied = authorization.removeprefix("Bearer ") if authorization else ""
    if not hmac.compare_digest(supplied.encode("utf-8"), configured.encode("utf-8")):
        raise HTTPException(status_code=401, detail="Invalid or missing bearer token.")


def _runtime_checks() -> list[str]:
    missing = [name for name in ("ffmpeg", "ffprobe") if shutil.which(name) is None]
    if not STORAGE_DIR.is_dir() or not os.access(STORAGE_DIR, os.W_OK):
        missing.append("writable AI_STORAGE_DIR")
    return missing


@app.get("/health")
async def health():
    """Public liveness check; contains no secrets or user/job data."""
    try:
        await asyncio.to_thread(job_store.database_healthy)
    except Exception:
        log.exception("Health check could not access the job database")
        raise HTTPException(status_code=503, detail="Job database is unavailable.")
    missing = await asyncio.to_thread(_runtime_checks)
    if missing:
        raise HTTPException(status_code=503, detail={"status": "unhealthy", "missing": missing})
    return {"status": "ok", "service": "AI Clip Studio processing API"}


@app.get("/ready")
async def ready():
    """Readiness check, including a recent heartbeat from the processor worker."""
    await health()
    age = await asyncio.to_thread(job_store.worker_age_seconds)
    if age is None or age > 45:
        raise HTTPException(status_code=503, detail="Processor worker is not ready.")
    return {"status": "ready", "worker_heartbeat_age_seconds": round(age, 1)}


@app.post("/v1/jobs", status_code=202)
async def create_job(
    request: Request,
    file: UploadFile = File(...),
    authorized: bool = Form(False),
    authorization: str | None = Header(default=None),
):
    _authorize(authorization)
    declared = request.headers.get("content-length")
    if declared and declared.isdigit() and int(declared) > MAX_UPLOAD_BYTES + 1_000_000:
        raise HTTPException(status_code=413, detail="Video exceeds the configured upload limit.")
    if not authorized:
        raise HTTPException(status_code=400, detail="Confirm you own this video or have permission to edit it.")

    extension = Path(file.filename or "").suffix.lower()
    if extension not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=415, detail="Choose a supported video file (MP4, MOV, MKV, WebM, M4V, or AVI).")

    STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    job_id = uuid.uuid4().hex
    job_dir = STORAGE_DIR / "jobs" / job_id
    output_dir = job_dir / "clips"
    job_dir.mkdir(parents=True, exist_ok=False)
    source = job_dir / f"source{extension}"
    copied = 0
    try:
        with source.open("wb") as destination:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                copied += len(chunk)
                if copied > MAX_UPLOAD_BYTES:
                    raise HTTPException(status_code=413, detail="Video exceeds the configured upload limit.")
                await asyncio.to_thread(destination.write, chunk)
        if copied == 0:
            raise HTTPException(status_code=400, detail="The uploaded video is empty.")
        await asyncio.to_thread(job_store.create_job, job_id, copied, source, output_dir)
    except Exception:
        shutil.rmtree(job_dir, ignore_errors=True)
        raise
    finally:
        await file.close()

    return {
        "id": job_id,
        "state": "queued",
        "upload_bytes": copied,
        # Relative path: behind a TLS-terminating proxy (Hugging Face Spaces) absolute URLs built
        # from the request come back as http://, which a strict HTTPS client must reject.
        "status_url": app.url_path_for("job_status", job_id=job_id),
    }


@app.get("/v1/jobs/{job_id}", name="job_status")
async def job_status(job_id: str, request: Request, authorization: str | None = Header(default=None)):
    _authorize(authorization)
    result = await asyncio.to_thread(job_store.get_job, job_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Job not found.")

    if result.get("state") == "complete":
        result["clips"] = [
            {
                **clip,
                "video_url": app.url_path_for("download_clip", job_id=job_id, filename=clip["video_file"]),
                "captions_url": app.url_path_for("download_clip", job_id=job_id, filename=clip["captions_file"]),
            }
            for clip in result["clips"]
        ]
    result.pop("source_path", None)
    result.pop("output_dir", None)
    return result


@app.get("/v1/jobs/{job_id}/clips/{filename}", name="download_clip")
async def download_clip(job_id: str, filename: str, authorization: str | None = Header(default=None)):
    _authorize(authorization)
    if Path(filename).name != filename or filename in {"", ".", ".."}:
        raise HTTPException(status_code=400, detail="Invalid clip filename.")
    job = await asyncio.to_thread(job_store.get_job, job_id)
    if job is None or job.get("state") != "complete":
        raise HTTPException(status_code=404, detail="Clip is not available.")
    allowed = {
        clip[name]
        for clip in job.get("clips", [])
        for name in ("video_file", "captions_file")
        if isinstance(clip.get(name), str)
    }
    if filename not in allowed:
        raise HTTPException(status_code=404, detail="Clip is not part of this job.")
    path = STORAGE_DIR / "jobs" / job_id / "clips" / filename
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Clip file is missing from backend storage.")
    media_type = "video/mp4" if path.suffix.lower() == ".mp4" else "application/x-subrip"
    return FileResponse(path, media_type=media_type, filename=filename)
