# AI Clip Studio backend (MVP-tuned, not deployed)

This backend processes only user-provided video files. It does not download YouTube media. No hosting account has been created and this service has not been deployed.

## MVP resource changes

- Faster-Whisper now defaults to **`tiny`**, CPU, `int8`, and `beam_size=1`. The environment variables remain available for a server operator to override the model/device/compute type.
- Scene detection samples by skipping two frames between processed frames (`frame_skip=2`).
- OpenCV seeks to one frame every two seconds instead of reading every frame in its Python loop, then scales the sampled frame down to at most 640 pixels on its longest side. Some long-GOP codecs may still decode nearby frames while seeking.
- FFmpeg renders portrait MP4 at **720×1280**.
- The upload limit defaults to **100,000,000 bytes (100 MB decimal)**. `MAX_UPLOAD_BYTES` can override it, so keep that setting at or below the MVP limit on the host.
- The worker handles one job at a time. SQLite claiming also refuses to start a second job while one is processing. Multiple jobs can wait in the queue, so free disk can still fill if uploads accumulate.
- At most **five** highlights are selected. Existing sentence-based candidate boundaries, padding, and per-clip SRT caption generation are retained.

These changes reduce work but do not guarantee a particular free host can run the service. They have not yet been benchmarked against a real 10-minute video.

## API endpoints

- `GET /health` — public liveness check: database, writable storage, FFmpeg and ffprobe.
- `GET /ready` — public readiness check, including processor heartbeat.
- `POST /v1/jobs` — bearer-authenticated multipart upload with `file` and `authorized=true` fields; responds `202` with a job ID.
- `GET /v1/jobs/{id}` — bearer-authenticated job state/progress.
- `GET /v1/jobs/{id}/clips/{filename}` — bearer-authenticated MP4/SRT download.

Set `AI_API_TOKEN` in the hosting dashboard's secret settings; never put it in the app or repository. The current token is shared by all callers, not a per-user login. The `authorized=true` field is a rights attestation, not proof of ownership. YouTube URLs are not accepted as media.

## Android-only manual test procedure (after a host is configured)

This procedure uses the Android browser; it does not require a PC or Python commands. A backend URL, its `AI_API_TOKEN`, and an HTTPS host are required first. The current Flet app is not connected to this API, so this is a direct backend test, not an in-app test.

1. In the Android browser, open `https://<your-backend-host>/health`, then `/ready`. Both should return success. If `/ready` is unavailable, do not upload yet; the worker is not ready.
2. Open `https://<your-backend-host>/docs`.
3. Expand **POST `/v1/jobs`** and tap **Try it out**. Enter `Bearer <your AI_API_TOKEN>` in the `authorization` header field, choose a video file under **100 MB**, and set `authorized` to `true` only if you have permission to edit that video. Tap **Execute**.
4. Confirm the response is `202` and has a job `id`. If it returns `413`, the file exceeds the cap; if it returns `401`/`503`, check the token/secret configuration. Do not paste the token into chat or a public screenshot.
5. Expand **GET `/v1/jobs/{job_id}`**, use the same bearer header and returned ID, and execute it again to check progress. Repeat until state is `complete` or `failed`. A failure response is a real failure, not a clip result.
6. For a completed job, check that it returns no more than five clips, with timestamps/transcript and caption URL for each. Use the corresponding authenticated clip-download endpoint in `/docs` to retrieve an MP4 and SRT. Confirm the MP4 is portrait 720×1280 and its SRT has time-coded caption entries. The docs UI may show a file download action for the MP4 response.
7. Repeat with a short, authorized video first. Only test a 10-minute video after a short test succeeds and the host has enough temporary disk. Remember that a host with ephemeral disk can lose the job and files after restart.

Do not run repeated uploads if the free host reports storage or memory pressure. Remove test jobs/files using the host's dashboard or an explicitly implemented cleanup process; there is currently no automatic retention/cleanup endpoint.

## Configuration and remaining limitations

- `AI_API_TOKEN`: required for job upload/status/download requests.
- `AI_STORAGE_DIR`: writable directory for SQLite, uploads, and outputs. Docker defaults to `/data/ai_clip_studio`.
- `MODEL_CACHE_DIR`: model cache; Docker defaults to `/data/models`.
- `ALLOWED_ORIGINS`: exact browser origins needed if calling from Flet web preview/web; the present Flet app has no backend client configured.
- Optional `MAX_UPLOAD_BYTES` (default 100,000,000), `WHISPER_MODEL` (`tiny`), `WHISPER_DEVICE` (`cpu`), and `WHISPER_COMPUTE_TYPE` (`int8`).

The model weights download on first processing use, requiring outbound internet and additional writable disk. Tiny is faster/lighter but generally less accurate than small. The ranking remains a heuristic, not semantic understanding; face and motion values are weak visual proxies. The portrait crop is centered, not subject-tracked. The host still needs enough memory, CPU time, container build capacity, and temporary disk. Without persistent storage, queued jobs, SQLite records, outputs, and possibly model cache can disappear on restart.

The Docker image has not been built here. The backend code has not been run against FastAPI, OpenCV, PySceneDetect, Faster-Whisper, FFmpeg, or an actual video in this environment; syntax checks alone do not validate those runtime integrations. A real upload-and-render test is still required before claiming the MVP works. FFmpeg uses `libx264`; check the selected FFmpeg build's license before distributing outputs or the service.
