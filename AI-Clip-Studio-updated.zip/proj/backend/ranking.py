"""Transparent, deterministic highlight scoring; this is not a trained model."""

from __future__ import annotations

from dataclasses import dataclass
import re


EXCITEMENT_TERMS = {
    "amazing", "awesome", "brilliant", "crazy", "exciting", "incredible", "insane",
    "love", "no way", "oh my god", "perfect", "seriously", "unbelievable", "wait", "wow",
}


@dataclass(frozen=True)
class TimedWord:
    text: str
    start: float
    end: float


@dataclass(frozen=True)
class Sentence:
    text: str
    start: float
    end: float
    words: tuple[TimedWord, ...]


@dataclass(frozen=True)
class Candidate:
    start: float
    end: float
    text: str
    words: tuple[TimedWord, ...]
    features: dict[str, float]
    score: float = 0.0


def make_timed_words(segments) -> list[TimedWord]:
    """Flatten Faster-Whisper word timestamps; estimate only if a segment lacks them."""
    result: list[TimedWord] = []
    for segment in segments:
        segment_words = getattr(segment, "words", None) or []
        if segment_words:
            for word in segment_words:
                text = str(getattr(word, "word", "")).strip()
                start = getattr(word, "start", None)
                end = getattr(word, "end", None)
                if text and start is not None and end is not None and end > start:
                    result.append(TimedWord(text, float(start), float(end)))
            continue

        tokens = re.findall(r"\S+", str(getattr(segment, "text", "")))
        start = float(getattr(segment, "start", 0.0))
        end = float(getattr(segment, "end", start))
        if not tokens or end <= start:
            continue
        width = (end - start) / len(tokens)
        result.extend(
            TimedWord(token, start + index * width, start + (index + 1) * width)
            for index, token in enumerate(tokens)
        )
    return sorted(result, key=lambda word: (word.start, word.end))


def split_sentences(words: list[TimedWord]) -> list[Sentence]:
    """Group timed words at punctuation or substantial pauses to preserve sentence edges."""
    sentences: list[Sentence] = []
    current: list[TimedWord] = []
    for index, word in enumerate(words):
        current.append(word)
        next_word = words[index + 1] if index + 1 < len(words) else None
        punctuation = word.text.rstrip('"\'”’)]}').endswith((".", "?", "!"))
        pause = next_word is None or next_word.start - word.end >= 0.85
        if punctuation or pause:
            sentences.append(
                Sentence(
                    text=" ".join(item.text for item in current).strip(),
                    start=current[0].start,
                    end=current[-1].end,
                    words=tuple(current),
                )
            )
            current = []
    if current:
        sentences.append(
            Sentence(
                text=" ".join(item.text for item in current).strip(),
                start=current[0].start,
                end=current[-1].end,
                words=tuple(current),
            )
        )
    return [sentence for sentence in sentences if sentence.end > sentence.start]


def generate_candidates(
    sentences: list[Sentence],
    video_duration: float,
    vad_intervals: list[tuple[float, float]],
    audio_energy,
    visual_samples: list[dict[str, float]],
    scene_times: list[float],
) -> list[Candidate]:
    """Create sentence-aligned windows and score speech, audio, motion, faces and cuts."""
    candidates: list[Candidate] = []
    if sentences:
        for first in range(len(sentences)):
            for last in range(first, len(sentences)):
                start = sentences[first].start
                end = sentences[last].end
                duration = end - start
                if duration > 40:
                    break
                if duration < 5 and last < len(sentences) - 1:
                    continue
                selected = sentences[first : last + 1]
                words = tuple(word for sentence in selected for word in sentence.words)
                text = " ".join(sentence.text for sentence in selected).strip()
                candidates.append(
                    Candidate(
                        start=start,
                        end=end,
                        text=text,
                        words=words,
                        features=_features(
                            start, end, text, words, vad_intervals,
                            audio_energy, visual_samples, scene_times,
                        ),
                    )
                )

    if not candidates:
        # Silent or non-speech videos still receive real scene-based candidates, never invented clips.
        step = 18.0
        window = min(28.0, max(6.0, video_duration))
        start = 0.0
        while start < video_duration:
            end = min(video_duration, start + window)
            if end > start:
                candidates.append(
                    Candidate(
                        start=start,
                        end=end,
                        text="",
                        words=(),
                        features=_features(
                            start, end, "", (), vad_intervals,
                            audio_energy, visual_samples, scene_times,
                        ),
                    )
                )
            if end >= video_duration:
                break
            start += step

    return _rank(candidates)


def _features(start, end, text, words, vad_intervals, audio_energy, visual_samples, scene_times):
    duration = max(0.01, end - start)
    speech_seconds = sum(
        max(0.0, min(end, vad_end) - max(start, vad_start))
        for vad_start, vad_end in vad_intervals
    )
    voice_coverage = min(1.0, speech_seconds / duration)
    lower_text = text.lower()
    excitement_count = sum(lower_text.count(term) for term in EXCITEMENT_TERMS)
    lexical = min(1.0, excitement_count / max(1.0, len(words) / 18.0))
    punctuation = min(1.0, (text.count("!") * 1.0 + text.count("?") * 0.5) / 3.0)
    words_per_minute = len(words) * 60.0 / duration
    cadence = min(1.0, max(0.0, (words_per_minute - 75.0) / 150.0))
    energy_values = [sample["energy"] for sample in audio_energy if start <= sample["time"] < end]
    energy = sum(energy_values) / len(energy_values) if energy_values else 0.0
    visual = [sample for sample in visual_samples if start <= sample["time"] < end]
    motion = sum(sample["motion"] for sample in visual) / len(visual) if visual else 0.0
    face = sum(sample["faces"] for sample in visual) / len(visual) if visual else 0.0
    cuts = sum(start <= scene_time <= end for scene_time in scene_times)
    scene_activity = min(1.0, cuts / max(1.0, duration / 8.0))
    return {
        "lexical": lexical,
        "punctuation": punctuation,
        "cadence": cadence,
        "voice_coverage": voice_coverage,
        "energy": energy,
        "motion": motion,
        "faces": face,
        "scene_activity": scene_activity,
    }


def _rank(candidates: list[Candidate]) -> list[Candidate]:
    if not candidates:
        return []
    feature_names = ("lexical", "punctuation", "cadence", "voice_coverage", "energy", "motion", "faces", "scene_activity")
    weights = {
        "lexical": 0.25,
        "punctuation": 0.06,
        "cadence": 0.07,
        "voice_coverage": 0.16,
        "energy": 0.13,
        "motion": 0.13,
        "faces": 0.08,
        "scene_activity": 0.12,
    }
    mins = {name: min(item.features[name] for item in candidates) for name in feature_names}
    maxs = {name: max(item.features[name] for item in candidates) for name in feature_names}
    scored = []
    for item in candidates:
        normalized = {
            name: (item.features[name] - mins[name]) / (maxs[name] - mins[name])
            if maxs[name] > mins[name]
            else item.features[name]
            for name in feature_names
        }
        score = 100.0 * sum(weights[name] * normalized[name] for name in feature_names)
        scored.append(Candidate(**{**item.__dict__, "score": round(score, 2)}))
    return sorted(scored, key=lambda item: (item.score, item.end - item.start), reverse=True)


def choose_top_highlights(candidates: list[Candidate], duration: float, limit: int = 5) -> list[dict]:
    """Pick up to five distinct moments with sentence-safe padding and timeline bounds."""
    selected: list[dict] = []
    for candidate in candidates:
        start = max(0.0, candidate.start - 0.65)
        end = min(duration, candidate.end + 0.85)
        if end <= start:
            continue
        if any(start < item["end"] + 1.0 and end > item["start"] - 1.0 for item in selected):
            continue
        selected.append(
            {
                "start": round(start, 3),
                "end": round(end, 3),
                "score": candidate.score,
                "text": candidate.text,
                "words": candidate.words,
                "features": candidate.features,
            }
        )
        if len(selected) == limit:
            break
    return selected
