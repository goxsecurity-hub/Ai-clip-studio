"""SQLite-backed job metadata and a single-worker durable queue."""

from __future__ import annotations

import json
import os
import sqlite3
import time
from pathlib import Path


STORAGE_DIR = Path(os.getenv("AI_STORAGE_DIR", "./ai_storage")).resolve()
DATABASE_PATH = STORAGE_DIR / "jobs.sqlite3"


def _connect():
    connection = sqlite3.connect(DATABASE_PATH, timeout=30)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA busy_timeout = 30000")
    return connection


def initialize() -> None:
    STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    with _connect() as connection:
        connection.execute("PRAGMA journal_mode = WAL")
        connection.execute(
            """CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY,
                state TEXT NOT NULL,
                stage TEXT NOT NULL,
                progress INTEGER NOT NULL DEFAULT 0,
                upload_bytes INTEGER NOT NULL,
                authorized_attestation INTEGER NOT NULL,
                source_path TEXT NOT NULL,
                output_dir TEXT NOT NULL,
                clips_json TEXT NOT NULL DEFAULT '[]',
                error TEXT,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            )"""
        )
        connection.execute(
            """CREATE TABLE IF NOT EXISTS worker_status (
                name TEXT PRIMARY KEY,
                heartbeat_at REAL NOT NULL
            )"""
        )


def create_job(job_id: str, upload_bytes: int, source_path: Path, output_dir: Path) -> None:
    now = time.time()
    with _connect() as connection:
        connection.execute(
            """INSERT INTO jobs (
                id, state, stage, progress, upload_bytes, authorized_attestation,
                source_path, output_dir, clips_json, created_at, updated_at
            ) VALUES (?, 'queued', 'Queued', 0, ?, 1, ?, ?, '[]', ?, ?)""",
            (job_id, upload_bytes, str(source_path), str(output_dir), now, now),
        )


def claim_next_job() -> dict | None:
    """Atomically claim one queued item; safe for multiple worker processes."""
    with _connect() as connection:
        connection.execute("BEGIN IMMEDIATE")
        active = connection.execute(
            "SELECT 1 FROM jobs WHERE state = 'processing' LIMIT 1"
        ).fetchone()
        if active is not None:
            connection.commit()
            return None
        row = connection.execute(
            "SELECT * FROM jobs WHERE state = 'queued' ORDER BY created_at LIMIT 1"
        ).fetchone()
        if row is None:
            connection.commit()
            return None
        now = time.time()
        connection.execute(
            "UPDATE jobs SET state='processing', stage='Starting analysis', progress=1, updated_at=? WHERE id=? AND state='queued'",
            (now, row["id"]),
        )
        connection.commit()
        result = dict(row)
        result.update(state="processing", stage="Starting analysis", progress=1)
        return result


def update_job(job_id: str, **fields) -> None:
    if "clips" in fields:
        fields["clips_json"] = json.dumps(fields.pop("clips"), ensure_ascii=False)
    allowed = {"state", "stage", "progress", "error", "clips_json"}
    fields = {key: value for key, value in fields.items() if key in allowed}
    if not fields:
        return
    fields["updated_at"] = time.time()
    assignments = ", ".join(f"{name} = ?" for name in fields)
    values = list(fields.values()) + [job_id]
    with _connect() as connection:
        connection.execute(f"UPDATE jobs SET {assignments} WHERE id = ?", values)


def get_job(job_id: str) -> dict | None:
    with _connect() as connection:
        row = connection.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
    if row is None:
        return None
    result = dict(row)
    result["clips"] = json.loads(result.pop("clips_json"))
    result["authorized_attestation"] = bool(result["authorized_attestation"])
    return result


def recover_interrupted_jobs() -> None:
    """Requeue jobs whose source survived a worker/server restart; fail missing inputs."""
    with _connect() as connection:
        rows = connection.execute(
            "SELECT id, source_path FROM jobs WHERE state IN ('queued', 'processing')"
        ).fetchall()
        now = time.time()
        for row in rows:
            if Path(row["source_path"]).is_file():
                connection.execute(
                    "UPDATE jobs SET state='queued', stage='Queued after restart', progress=0, error=NULL, updated_at=? WHERE id=?",
                    (now, row["id"]),
                )
            else:
                connection.execute(
                    "UPDATE jobs SET state='failed', stage='Failed after restart', error='The temporary source video was missing after restart.', updated_at=? WHERE id=?",
                    (now, row["id"]),
                )


def heartbeat() -> None:
    with _connect() as connection:
        connection.execute(
            "INSERT INTO worker_status(name, heartbeat_at) VALUES('processor', ?) "
            "ON CONFLICT(name) DO UPDATE SET heartbeat_at=excluded.heartbeat_at",
            (time.time(),),
        )


def database_healthy() -> bool:
    with _connect() as connection:
        connection.execute("SELECT 1 FROM jobs LIMIT 1").fetchone()
    return True


def worker_age_seconds() -> float | None:
    with _connect() as connection:
        row = connection.execute(
            "SELECT heartbeat_at FROM worker_status WHERE name='processor'"
        ).fetchone()
    return None if row is None else max(0.0, time.time() - float(row["heartbeat_at"]))
