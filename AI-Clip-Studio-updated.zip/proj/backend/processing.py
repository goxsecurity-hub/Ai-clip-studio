"""CPU-oriented backend pipeline for authorized user-provided videos."""

from __future__ import annotations

import json
import os
import subprocess
import wave
from functools import lru_cache
from pathlib import Path

import numpy as np

from ranking import choose_top_highlights, generate_candidates, make_timed_words, split_sentences

MAX_HIGHLIGHTS = 5


@lru_cache(maxsize=1)
def _whisper_model():
    from faster_whisper import WhisperModel

    model_name = os.getenv("WHISPER_MODEL", "tiny")
    cache_dir = os.getenv("MODEL_CACHE_DIR")
    return WhisperModel(
        model_name,
        device=os.getenv("WHISPER_DEVICE", "cpu"),
        compute_type=os.getenv("WHISPER_COMPUTE_TYPE", "int8"),
        download_root=cache_dir,
    )


@lru_cache(maxsize=1)
def _silero_model():
    from silero_vad import load_silero_vad

    return load_silero_vad()


def _run(command: list[str], timeout: int = 900):
    return subprocess.run(command, check=True, capture_output=True, text=True, timeout=timeout)


def _probe_video(path: Path) -> tuple[float, bool]:
    result = _run(
        [
            "ffprobe", "-v", "error", "-show_streams", "-show_format",
            "-of", "json", str(path),
        ],
        timeout=60,
    )
    metadata = json.loads(result.stdout)
    duration = float(metadata.get("format", {}).get("duration", 0))
    has_audio = any(stream.get("codec_type") == "audio" for stream in metadata.get("streams", []))
    has_video = any(stream.get("codec_type") == "video" for stream in metadata.get("streams", []))
    if not has_video or duration <= 0:
        raise ValueError("The selected file does not contain a readable video stream.")
    return duration, has_audio


def _extract_audio(video_path: Path, wav_path: Path) -> None:
    _run(
        [
            "ffmpeg", "-y", "-v", "error", "-i", str(video_path), "-vn",
            "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(wav_path),
        ],
        timeout=900,
    )


def _vad_intervals(wav_path: Path) -> list[tuple[float, float]]:
    import torch
    from silero_vad import get_speech_timestamps

    with wave.open(str(wav_path), "rb") as audio_file:
        if audio_file.getsampwidth() != 2 or audio_file.getnchannels() != 1 or audio_file.getframerate() != 16000:
            raise ValueError("Internal audio conversion did not produce 16 kHz mono PCM.")
        samples = np.frombuffer(audio_file.readframes(audio_file.getnframes()), dtype=np.int16)
    if samples.size == 0:
        return []
    audio_tensor = torch.from_numpy(samples.astype(np.float32) / 32768.0)
    spans = get_speech_timestamps(
        audio_tensor,
        _silero_model(),
        sampling_rate=16000,
        return_seconds=True,
    )
    return [(float(span["start"]), float(span["end"])) for span in spans]


def _transcribe(wav_path: Path):
    segments, info = _whisper_model().transcribe(
        str(wav_path),
        beam_size=1,
        word_timestamps=True,
        vad_filter=False,
    )
    return list(segments), info


def _audio_energy(wav_path: Path) -> list[dict[str, float]]:
    samples_per_window = 4000  # 250 ms at 16 kHz
    with wave.open(str(wav_path), "rb") as audio_file:
        samples = np.frombuffer(audio_file.readframes(audio_file.getnframes()), dtype=np.int16)
    if samples.size == 0:
        return []
    result = []
    for start in range(0, len(samples), samples_per_window):
        block = samples[start : start + samples_per_window].astype(np.float32) / 32768.0
        rms = float(np.sqrt(np.mean(np.square(block)))) if block.size else 0.0
        result.append({"time": start / 16000.0, "energy": rms})
    return result


def _detect_scenes(video_path: Path) -> list[float]:
    from scenedetect import ContentDetector, SceneManager, open_video

    video = open_video(str(video_path))
    manager = SceneManager()
    manager.add_detector(ContentDetector(threshold=27.0, min_scene_len=15))
    # Analyze every third frame rather than every frame to reduce CPU work.
    manager.detect_scenes(video, show_progress=False, frame_skip=2)
    return [scene[0].get_seconds() for scene in manager.get_scene_list()]


def _analyze_frames(video_path: Path) -> list[dict[str, float]]:
    """Seek to one frame every two seconds instead of decoding every source frame in Python."""
    import cv2

    capture = cv2.VideoCapture(str(video_path))
    if not capture.isOpened():
        raise ValueError("OpenCV could not open the uploaded video for frame analysis.")
    fps = float(capture.get(cv2.CAP_PROP_FPS))
    frame_count = float(capture.get(cv2.CAP_PROP_FRAME_COUNT))
    if fps <= 0 or frame_count <= 0:
        capture.release()
        raise ValueError("OpenCV could not determine the video duration for sampled frame analysis.")
    duration = frame_count / fps
    detector = cv2.CascadeClassifier(
        str(Path(cv2.data.haarcascades) / "haarcascade_frontalface_default.xml")
    )
    if detector.empty():
        # Face signal is a weak optional proxy; do not fail the whole job without it.
        detector = None
    samples = []
    previous = None
    sample_interval = 2.0
    try:
        sample_time = 0.0
        while sample_time < duration:
            # Seeking lets the decoder jump near the requested timestamp. Long-GOP
            # formats may decode a few frames around the seek point, but not the
            # entire video frame-by-frame in this Python loop.
            seek_ok = capture.set(cv2.CAP_PROP_POS_MSEC, sample_time * 1000.0)
            if not seek_ok:
                capture.set(cv2.CAP_PROP_POS_FRAMES, round(sample_time * fps))
            ok, frame = capture.read()
            if not ok:
                break
            timestamp = capture.get(cv2.CAP_PROP_POS_MSEC) / 1000.0
            if timestamp <= 0 and sample_time > 0:
                timestamp = sample_time
            height, width = frame.shape[:2]
            scale = min(1.0, 640.0 / max(width, height))
            if scale < 1.0:
                frame = cv2.resize(frame, (int(width * scale), int(height * scale)))
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            motion = 0.0 if previous is None else float(np.mean(cv2.absdiff(gray, previous)) / 255.0)
            faces = (
                detector.detectMultiScale(gray, scaleFactor=1.15, minNeighbors=4, minSize=(24, 24))
                if detector is not None
                else []
            )
            face_area = sum(w * h for _, _, w, h in faces) / max(1, gray.shape[0] * gray.shape[1])
            samples.append({"time": timestamp, "motion": motion, "faces": float(min(1.0, face_area * 8.0))})
            previous = gray
            sample_time += sample_interval
    finally:
        capture.release()
    return samples


def _srt_time(seconds: float) -> str:
    milliseconds = max(0, round(seconds * 1000))
    hours, remainder = divmod(milliseconds, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    seconds_part, millis = divmod(remainder, 1000)
    return f"{hours:02}:{minutes:02}:{seconds_part:02},{millis:03}"


def _write_captions(words, clip_start: float, clip_end: float, destination: Path) -> None:
    selected = [word for word in words if word.end > clip_start and word.start < clip_end]
    entries = []
    current = []
    for word in selected:
        current.append(word)
        phrase = " ".join(item.text for item in current)
        elapsed = current[-1].end - current[0].start
        terminal = current[-1].text.rstrip('"\'”’)]}').endswith((".", "?", "!"))
        if len(current) >= 8 or elapsed >= 3.0 or terminal:
            entries.append(current)
            current = []
    if current:
        entries.append(current)

    lines = []
    for index, phrase_words in enumerate(entries, start=1):
        start = max(clip_start, phrase_words[0].start)
        end = min(clip_end, phrase_words[-1].end)
        if end <= start:
            continue
        lines.extend(
            [
                str(index),
                f"{_srt_time(start - clip_start)} --> {_srt_time(end - clip_start)}",
                " ".join(word.text for word in phrase_words),
                "",
            ]
        )
    destination.write_text("\n".join(lines), encoding="utf-8")


def _render_clip(video_path: Path, start: float, end: float, destination: Path) -> None:
    duration = end - start
    if duration <= 0:
        raise ValueError("Highlight timestamps are invalid.")
    _run(
        [
            "ffmpeg", "-y", "-v", "error", "-ss", f"{start:.3f}", "-i", str(video_path),
            "-t", f"{duration:.3f}", "-map", "0:v:0", "-map", "0:a?",
            "-vf", "scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
            "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k",
            "-movflags", "+faststart", str(destination),
        ],
        timeout=900,
    )


def process_authorized_video(video_path: Path, output_dir: Path, progress) -> list[dict]:
    """Run actual transcription, VAD, scene/frame analysis, ranking and rendering."""
    output_dir.mkdir(parents=True, exist_ok=True)
    progress("Validating video", 5)
    duration, has_audio = _probe_video(video_path)
    wav_path = output_dir / "analysis_audio.wav"
    vad_intervals: list[tuple[float, float]] = []
    energy: list[dict[str, float]] = []
    words = []

    if has_audio:
        progress("Preparing audio", 12)
        _extract_audio(video_path, wav_path)
        progress("Detecting speech with Silero VAD", 24)
        vad_intervals = _vad_intervals(wav_path)
        progress("Transcribing with Faster-Whisper", 42)
        segments, _info = _transcribe(wav_path)
        words = make_timed_words(segments)
        energy = _audio_energy(wav_path)

    wav_path.unlink(missing_ok=True)
    progress("Detecting scene changes", 56)
    scene_times = _detect_scenes(video_path)
    progress("Analyzing frames with OpenCV", 67)
    visual_samples = _analyze_frames(video_path)
    sentences = split_sentences(words)
    candidates = generate_candidates(
        sentences,
        duration,
        vad_intervals,
        energy,
        visual_samples,
        scene_times,
    )
    highlights = choose_top_highlights(candidates, duration, limit=MAX_HIGHLIGHTS)
    if not highlights:
        raise ValueError("No highlight windows could be found in this video; no clips were rendered.")

    results = []
    for index, highlight in enumerate(highlights, start=1):
        progress(f"Rendering clip {index} of {len(highlights)}", 70 + int(25 * (index - 1) / len(highlights)))
        video_name = f"highlight_{index}.mp4"
        caption_name = f"highlight_{index}.srt"
        video_output = output_dir / video_name
        caption_output = output_dir / caption_name
        _render_clip(video_path, highlight["start"], highlight["end"], video_output)
        _write_captions(words, highlight["start"], highlight["end"], caption_output)
        results.append(
            {
                "rank": index,
                "start": highlight["start"],
                "end": highlight["end"],
                "score": highlight["score"],
                "transcript": highlight["text"],
                "video_file": video_name,
                "captions_file": caption_name,
                "ranking_signals": highlight["features"],
            }
        )
    progress("Complete", 100)
    return results
