"""Single processing worker; API requests only enqueue durable jobs."""

from __future__ import annotations

import logging
import os
import threading
import time
from pathlib import Path

import job_store
from processing import process_authorized_video

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("ai_clip_worker")


def _heartbeat_loop() -> None:
    while True:
        try:
            job_store.heartbeat()
        except Exception:
            log.exception("Could not update worker heartbeat")
        time.sleep(10)


def _process(job: dict) -> None:
    job_id = job["id"]
    source = Path(job["source_path"])
    output_dir = Path(job["output_dir"])
    log.info("Starting job %s (%s bytes)", job_id, job["upload_bytes"])

    def progress(stage: str, percent: int) -> None:
        job_store.update_job(job_id, stage=stage, progress=max(0, min(100, int(percent))))

    try:
        clips = process_authorized_video(source, output_dir, progress)
        job_store.update_job(job_id, state="complete", stage="Complete", progress=100, clips=clips)
        log.info("Completed job %s with %s clips", job_id, len(clips))
    except Exception as exc:
        log.exception("Highlight processing failed for job %s", job_id)
        job_store.update_job(job_id, state="failed", stage="Failed", error=str(exc))
    finally:
        source.unlink(missing_ok=True)


def main() -> None:
    job_store.initialize()
    # This deployment runs one processor. On restart, retry queued/in-progress
    # jobs only when their source file is still on persistent storage.
    job_store.recover_interrupted_jobs()
    threading.Thread(target=_heartbeat_loop, daemon=True, name="worker-heartbeat").start()
    log.info("Worker started; waiting for queued jobs")
    while True:
        try:
            job = job_store.claim_next_job()
            if job is None:
                time.sleep(1)
                continue
            _process(job)
        except Exception:
            log.exception("Worker loop failed")
            time.sleep(3)


if __name__ == "__main__":
    main()
