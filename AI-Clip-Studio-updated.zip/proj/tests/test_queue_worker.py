"""Real SQLite queue + real worker loop body + real processing (ML stubbed)."""
import importlib
import shutil

import pytest


@pytest.fixture
def store(tmp_path, monkeypatch):
    monkeypatch.setenv("AI_STORAGE_DIR", str(tmp_path / "storage"))
    import job_store
    importlib.reload(job_store)
    job_store.initialize()
    return job_store


def _enqueue(store, tmp_path, video, name):
    job_dir = tmp_path / "storage" / "jobs" / name
    job_dir.mkdir(parents=True)
    src = job_dir / "source.mp4"
    shutil.copy(video, src)
    store.create_job(name, src.stat().st_size, src, job_dir / "clips")
    return src


def test_job_lifecycle_through_worker(store, sample_video, stub_models, tmp_path):
    import worker
    importlib.reload(worker)
    src = _enqueue(store, tmp_path, sample_video, "a" * 32)
    assert store.get_job("a" * 32)["state"] == "queued"

    job = store.claim_next_job()
    assert job["id"] == "a" * 32
    assert store.claim_next_job() is None, "must not start a second job while one is processing"

    worker._process(job)
    done = store.get_job("a" * 32)
    assert done["state"] == "complete" and done["progress"] == 100
    assert 1 <= len(done["clips"]) <= 5
    assert not src.exists(), "source upload is deleted after processing"
    assert (tmp_path / "storage" / "jobs" / ("a" * 32) / "clips" / done["clips"][0]["video_file"]).is_file()


def test_failed_job_records_error(store, tmp_path):
    import worker
    importlib.reload(worker)
    bad = tmp_path / "bad.mp4"
    bad.write_bytes(b"garbage")
    _enqueue(store, tmp_path, bad, "b" * 32)
    worker._process(store.claim_next_job())
    job = store.get_job("b" * 32)
    assert job["state"] == "failed" and job["error"]


def test_restart_recovery_requeues_or_fails(store, sample_video, tmp_path):
    _enqueue(store, tmp_path, sample_video, "c" * 32)
    store.claim_next_job()  # now 'processing', as if the worker died mid-job
    _enqueue(store, tmp_path, sample_video, "d" * 32).unlink()  # source lost
    store.recover_interrupted_jobs()
    assert store.get_job("c" * 32)["state"] == "queued"
    failed = store.get_job("d" * 32)
    assert failed["state"] == "failed" and "missing" in failed["error"]
