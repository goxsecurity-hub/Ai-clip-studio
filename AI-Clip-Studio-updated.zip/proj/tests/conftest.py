"""Shared fixtures.

HONESTY NOTE: the sandbox these tests were written in has no faster-whisper, silero-vad,
scenedetect, torch or fastapi. Those four are replaced by clearly-marked stubs in
`stub_models`. Everything else (ffprobe/ffmpeg, OpenCV frame analysis, ranking, SRT writer,
SQLite queue, worker, the Flet-side HTTP client) is the real project code.
Run the same tests in the Docker image to exercise the real models (see tests/README.md).
"""
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
sys.path.insert(0, str(ROOT / "src"))


def _ffmpeg(*args):
    subprocess.run(["ffmpeg", "-y", "-v", "error", *args], check=True)


@pytest.fixture(scope="session")
def sample_video(tmp_path_factory):
    """40 s 1280x720 H.264 + AAC (landscape, the common phone-gallery case)."""
    out = tmp_path_factory.mktemp("media") / "sample.mp4"
    _ffmpeg(
        "-f", "lavfi", "-i", "testsrc2=size=1280x720:rate=30:duration=40",
        "-f", "lavfi", "-i", "sine=frequency=440:duration=40",
        "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", "-c:a", "aac", str(out),
    )
    return out


@pytest.fixture(scope="session")
def silent_video(tmp_path_factory):
    out = tmp_path_factory.mktemp("media") / "silent.mp4"
    _ffmpeg(
        "-f", "lavfi", "-i", "testsrc2=size=640x360:rate=24:duration=14",
        "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", str(out),
    )
    return out


def _words():
    sentences = [
        "So today we talk about something quite ordinary.",
        "Here is a normal boring sentence about nothing.",
        "Wow, this is amazing and incredible!",
        "I cannot believe it, no way, that is unbelievable!",
        "Let us go back to calm and steady talking now.",
        "Another plain sentence follows here for padding.",
        "Seriously, this part is insane, wait for it!",
        "And that is perfect, I love it so much!",
        "Closing remarks arrive at a slow quiet pace.",
        "Thanks for watching this very long sample video.",
    ]
    words, t = [], 1.0
    for sentence in sentences:
        for token in sentence.split():
            words.append(SimpleNamespace(word=" " + token, start=t, end=t + 0.42))
            t += 0.5
        t += 1.0
    return words


@pytest.fixture
def stub_models(monkeypatch):
    """Replace ONLY the unavailable ML models (Whisper, Silero VAD, PySceneDetect)."""
    import processing

    words = _words()
    segment = SimpleNamespace(words=words, text="", start=words[0].start, end=words[-1].end)
    monkeypatch.setattr(processing, "_transcribe", lambda wav: ([segment], SimpleNamespace()))
    monkeypatch.setattr(processing, "_vad_intervals", lambda wav: [(1.0, words[-1].end)])
    monkeypatch.setattr(processing, "_detect_scenes", lambda video: [10.0, 20.0, 30.0])
    return words
