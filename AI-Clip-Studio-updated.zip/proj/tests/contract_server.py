"""Starlette stand-in for backend/server.py, used ONLY because FastAPI is not installed in the
authoring sandbox. It mirrors server.py's routes, status codes, auth and relative-URL contract,
and is backed by the real job_store/worker/processing code. It is NOT a test of FastAPI routing:
run backend/server.py itself in the Docker image (tests/README.md) to cover that."""
import os
import shutil
import threading
import time
import uuid
from pathlib import Path

import uvicorn
from starlette.applications import Starlette
from starlette.exceptions import HTTPException
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse
from starlette.routing import Route

TOKEN = "test-token-123"
ALLOWED = {".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi"}


def build(job_store, worker, storage: Path, max_bytes: int):
    def auth(request):
        if request.headers.get("authorization", "") != f"Bearer {TOKEN}":
            raise HTTPException(401, "Invalid or missing bearer token.")

    async def create(request: Request):
        auth(request)
        form = await request.form()
        if form.get("authorized") != "true":
            raise HTTPException(400, "Confirm you own this video or have permission to edit it.")
        upload = form["file"]
        ext = Path(upload.filename or "").suffix.lower()
        if ext not in ALLOWED:
            raise HTTPException(415, "Choose a supported video file (MP4, MOV, MKV, WebM, M4V, or AVI).")
        data = await upload.read()
        if len(data) > max_bytes:
            raise HTTPException(413, "Video exceeds the configured upload limit.")
        if not data:
            raise HTTPException(400, "The uploaded video is empty.")
        job_id = uuid.uuid4().hex
        job_dir = storage / "jobs" / job_id
        job_dir.mkdir(parents=True)
        src = job_dir / f"source{ext}"
        src.write_bytes(data)
        job_store.create_job(job_id, len(data), src, job_dir / "clips")
        return JSONResponse({"id": job_id, "state": "queued", "upload_bytes": len(data),
                             "status_url": f"/v1/jobs/{job_id}"}, status_code=202)

    async def status(request: Request):
        auth(request)
        job_id = request.path_params["job_id"]
        job = job_store.get_job(job_id)
        if job is None:
            raise HTTPException(404, "Job not found.")
        if job["state"] == "complete":
            job["clips"] = [{**c, "video_url": f"/v1/jobs/{job_id}/clips/{c['video_file']}",
                             "captions_url": f"/v1/jobs/{job_id}/clips/{c['captions_file']}"}
                            for c in job["clips"]]
        job.pop("source_path", None); job.pop("output_dir", None)
        return JSONResponse(job)

    async def clip(request: Request):
        auth(request)
        job_id, name = request.path_params["job_id"], request.path_params["filename"]
        job = job_store.get_job(job_id)
        if not job or job["state"] != "complete":
            raise HTTPException(404, "Clip is not available.")
        allowed = {c[k] for c in job["clips"] for k in ("video_file", "captions_file")}
        if name not in allowed:
            raise HTTPException(404, "Clip is not part of this job.")
        path = storage / "jobs" / job_id / "clips" / name
        mt = "video/mp4" if path.suffix == ".mp4" else "application/x-subrip"
        return FileResponse(path, media_type=mt, filename=name)

    async def http_error(request, exc):  # FastAPI's error shape: {"detail": "..."}
        return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)

    return Starlette(exception_handlers={HTTPException: http_error}, routes=[
        Route("/v1/jobs", create, methods=["POST"]),
        Route("/v1/jobs/{job_id}", status),
        Route("/v1/jobs/{job_id}/clips/{filename}", clip),
    ])


class Running:
    """uvicorn on a real TCP port plus the real worker loop body in a thread."""
    def __init__(self, app, job_store, worker):
        self.config = uvicorn.Config(app, host="127.0.0.1", port=0, log_level="warning")
        self.server = uvicorn.Server(self.config)
        self.stop = threading.Event()
        self.t_srv = threading.Thread(target=self.server.run, daemon=True)
        self.t_wrk = threading.Thread(target=self._work, args=(job_store, worker), daemon=True)

    def _work(self, job_store, worker):
        while not self.stop.is_set():
            job = job_store.claim_next_job()
            if job is None:
                time.sleep(0.2)
            else:
                worker._process(job)

    def __enter__(self):
        self.t_srv.start(); self.t_wrk.start()
        for _ in range(100):
            if self.server.started and self.server.servers:
                break
            time.sleep(0.1)
        port = self.server.servers[0].sockets[0].getsockname()[1]
        self.url = f"http://127.0.0.1:{port}"
        return self

    def __exit__(self, *exc):
        self.stop.set(); self.server.should_exit = True
        self.t_srv.join(5)
