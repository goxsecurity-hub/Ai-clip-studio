# Tests

    pip install pytest numpy opencv-python-headless httpx2 uvicorn starlette python-multipart
    python -m pytest tests -q          # needs ffmpeg/ffprobe on PATH

What is real vs stubbed (see `conftest.py`, `contract_server.py`):
- REAL: ffprobe/ffmpeg render (720x1280 H.264/AAC), OpenCV frame analysis, ranking, SRT, SQLite queue,
  worker, and `src/backend_api.py` over real TCP.
- STUBBED: Faster-Whisper, Silero VAD, PySceneDetect (not installable where these were written) and the
  FastAPI routing layer (a Starlette stand-in mirrors `backend/server.py`'s contract).

To cover the stubs, run inside the backend Docker image / a venv with `backend/requirements.txt`:
start `uvicorn server:app` + `python worker.py` with `AI_API_TOKEN` set, then follow the manual
procedure in `backend/README.md` (or point `src/backend_api.py` at it).
