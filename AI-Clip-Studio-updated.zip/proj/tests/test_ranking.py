import ranking
from ranking import TimedWord


def _w(text, s):
    return TimedWord(text, s, s + 0.4)


def test_sentences_split_on_punctuation_and_pause():
    words = [_w("Hello", 0), _w("world.", 0.5), _w("Again", 1.0), _w("late", 5.0)]
    sentences = ranking.split_sentences(words)
    assert [s.text for s in sentences] == ["Hello world.", "Again", "late"]


def test_excited_sentence_outranks_plain_one():
    plain = [_w(t, i * 0.5) for i, t in enumerate("this is a plain sentence about nothing at all today.".split())]
    wow = [_w(t, 20 + i * 0.5) for i, t in enumerate("wow this is amazing and incredible, unbelievable!".split())]
    sentences = ranking.split_sentences(plain + wow)
    cands = ranking.generate_candidates(sentences, 40.0, [(0, 40)], [], [], [])
    top = ranking.choose_top_highlights(cands, 40.0, limit=1)[0]
    assert "wow" in top["text"].lower()


def test_highlights_do_not_overlap_and_are_limited():
    words, t = [], 0.0
    for i in range(30):
        for tok in f"Sentence number {i} is here wow!".split():
            words.append(_w(tok, t)); t += 0.5
        t += 1.0
    sentences = ranking.split_sentences(words)
    cands = ranking.generate_candidates(sentences, t, [(0, t)], [], [], [])
    picks = ranking.choose_top_highlights(cands, t, limit=5)
    assert 1 <= len(picks) <= 5
    spans = sorted((p["start"], p["end"]) for p in picks)
    assert all(a_end <= b_start for (_, a_end), (b_start, _) in zip(spans, spans[1:]))
    assert all(0 <= s < e <= t for s, e in spans)


def test_silent_video_gets_scene_based_candidates():
    cands = ranking.generate_candidates([], 14.0, [], [], [], [3.0, 9.0])
    assert cands and all(c.text == "" for c in cands)
    picks = ranking.choose_top_highlights(cands, 14.0)
    assert picks and picks[0]["end"] <= 14.0
