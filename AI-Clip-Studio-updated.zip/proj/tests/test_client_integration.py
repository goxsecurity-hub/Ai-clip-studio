"""Flet-side HTTP client (src/backend_api.py, unmodified runtime code) over real TCP to the
contract server, which runs the real queue + worker + FFmpeg pipeline (ML stubbed)."""
import asyncio
import importlib
import json
import subprocess
import time

import pytest

import backend_api
import contract_server


@pytest.fixture
def server(tmp_path, monkeypatch, stub_models):
    monkeypatch.setenv("AI_STORAGE_DIR", str(tmp_path / "storage"))
    import job_store, worker
    importlib.reload(job_store); importlib.reload(worker)
    job_store.initialize()
    app = contract_server.build(job_store, worker, tmp_path / "storage", max_bytes=50_000_000)
    with contract_server.Running(app, job_store, worker) as running:
        yield running


def run(coro):
    return asyncio.run(coro)


async def _poll(url, token, job_id, timeout=120):
    seen, t0 = [], time.time()
    while time.time() - t0 < timeout:
        job = await backend_api.get_job_status(url, token, job_id)
        seen.append((job["state"], job.get("progress", 0)))
        if job["state"] in ("complete", "failed"):
            return job, seen
        await asyncio.sleep(0.5)
    raise TimeoutError(seen[-3:])


def test_upload_process_preview_and_export(server, sample_video, tmp_path):
    """video file -> upload -> AI processing -> highlights -> download MP4 (preview/save) + SRT."""
    async def flow():
        sub = await backend_api.submit_video(server.url, contract_server.TOKEN, str(sample_video))
        assert sub["state"] == "queued" and sub["status_url"].startswith("/v1/jobs/")
        job, seen = await _poll(server.url, contract_server.TOKEN, sub["id"])
        return job, seen

    job, seen = run(flow())
    assert job["state"] == "complete", job
    progress = [p for _, p in seen]
    assert progress == sorted(progress) and progress[-1] == 100
    assert 1 <= len(job["clips"]) <= 5

    for clip in job["clips"]:
        assert clip["video_url"].startswith("/v1/jobs/")  # relative: proxy-safe
        mp4 = run(backend_api.download_result(server.url, contract_server.TOKEN, clip["video_url"]))
        srt = run(backend_api.download_result(server.url, contract_server.TOKEN, clip["captions_url"]))
        path = tmp_path / f"clip{clip['rank']}.mp4"
        path.write_bytes(mp4)
        meta = json.loads(subprocess.run(
            ["ffprobe", "-v", "error", "-show_streams", "-of", "json", str(path)],
            check=True, capture_output=True, text=True).stdout)
        v = next(s for s in meta["streams"] if s["codec_type"] == "video")
        assert (v["width"], v["height"]) == (720, 1280)
        assert b"-->" in srt and srt.decode("utf-8").startswith("1\n")


def test_bad_token_gives_clear_error(server, sample_video):
    with pytest.raises(RuntimeError, match="Invalid or missing bearer token"):
        run(backend_api.submit_video(server.url, "wrong", str(sample_video)))


def test_unsupported_extension_reports_backend_message(server, tmp_path):
    f = tmp_path / "doc.txt"; f.write_bytes(b"hello")
    with pytest.raises(RuntimeError, match="supported video file"):
        run(backend_api.submit_video(server.url, contract_server.TOKEN, str(f)))


def test_client_side_validation(tmp_path):
    empty = tmp_path / "e.mp4"; empty.write_bytes(b"")
    with pytest.raises(ValueError, match="empty"):
        run(backend_api.submit_video("https://x.example", "t", str(empty)))
    with pytest.raises(ValueError, match="token"):
        run(backend_api.submit_video("https://x.example", " ", str(empty)))


@pytest.mark.parametrize("bad", [
    "http://example.com", "ftp://x.example", "https://u:p@x.example", "https://x.example/path",
    "https://x.example?q=1", "http://8.8.8.8", "https://x.example:99999", "",
])
def test_backend_url_rejections(bad):
    with pytest.raises(ValueError):
        backend_api.normalize_backend_url(bad)


@pytest.mark.parametrize("ok", [
    "https://me-space.hf.space", "https://me-space.hf.space/", "http://127.0.0.1:7860",
    "http://192.168.1.20:7860", "http://10.0.2.2:7860", "http://localhost:7860",
])
def test_backend_url_accepts(ok):
    assert backend_api.normalize_backend_url(ok).startswith("http")


def test_result_url_resolution_is_token_safe():
    base = "https://me.hf.space"
    r = backend_api.resolve_result_url
    assert r(base, "/v1/jobs/abc/clips/h.mp4") == "https://me.hf.space/v1/jobs/abc/clips/h.mp4"
    # proxy-misreported scheme from the same host is repaired to the configured https origin
    assert r(base, "http://me.hf.space/v1/jobs/abc/clips/h.mp4") == "https://me.hf.space/v1/jobs/abc/clips/h.mp4"
    for evil in ("https://evil.example/v1/jobs/a/clips/x", "//evil.example/v1/jobs/a/clips/x",
                 "/etc/passwd", "https://me.hf.space:444/v1/jobs/a/clips/x", "https://u:p@me.hf.space/v1/jobs/a"):
        with pytest.raises(ValueError):
            r(base, evil)
