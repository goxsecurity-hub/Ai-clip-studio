"""Real ffmpeg/ffprobe/OpenCV/ranking/SRT on real files (Whisper/VAD/scenes stubbed)."""
import json
import re
import subprocess

import processing


def _probe(path):
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)],
        check=True, capture_output=True, text=True,
    ).stdout
    return json.loads(out)


def test_full_pipeline_renders_portrait_mp4_and_srt(sample_video, stub_models, tmp_path):
    stages = []
    clips = processing.process_authorized_video(sample_video, tmp_path / "out", lambda s, p: stages.append((s, p)))

    assert 1 <= len(clips) <= 5
    assert stages[0][0] == "Validating video" and stages[-1] == ("Complete", 100)
    percents = [p for _, p in stages]
    assert percents == sorted(percents), "progress must never go backwards"
    assert not (tmp_path / "out" / "analysis_audio.wav").exists(), "temp WAV should be cleaned up"

    for clip in clips:
        mp4 = tmp_path / "out" / clip["video_file"]
        meta = _probe(mp4)
        video = next(s for s in meta["streams"] if s["codec_type"] == "video")
        audio = next(s for s in meta["streams"] if s["codec_type"] == "audio")
        assert (video["width"], video["height"]) == (720, 1280)
        assert video["codec_name"] == "h264" and audio["codec_name"] == "aac"
        expected = clip["end"] - clip["start"]
        assert abs(float(meta["format"]["duration"]) - expected) < 0.6

        srt = (tmp_path / "out" / clip["captions_file"]).read_text(encoding="utf-8")
        blocks = [b for b in srt.strip().split("\n\n") if b]
        assert blocks, "SRT must contain caption cues for a clip that has speech"
        last_end = 0.0
        for n, block in enumerate(blocks, start=1):
            lines = block.split("\n")
            assert lines[0] == str(n)
            m = re.fullmatch(r"(\d\d):(\d\d):(\d\d),(\d{3}) --> (\d\d):(\d\d):(\d\d),(\d{3})", lines[1])
            assert m, lines[1]
            h1, m1, s1, ms1, h2, m2, s2, ms2 = map(int, m.groups())
            start = h1 * 3600 + m1 * 60 + s1 + ms1 / 1000
            end = h2 * 3600 + m2 * 60 + s2 + ms2 / 1000
            assert start < end and start >= last_end - 1e-6
            assert end <= expected + 0.1
            last_end = end
            assert lines[2].strip()

    top = clips[0]
    assert any(w in top["transcript"].lower() for w in ("wow", "unbelievable", "insane", "perfect"))


def test_silent_video_still_produces_real_clips(silent_video, tmp_path, monkeypatch):
    # Only scene detection is stubbed: with no audio track Whisper/VAD are never invoked.
    monkeypatch.setattr(processing, "_detect_scenes", lambda video: [5.0])
    clips = processing.process_authorized_video(silent_video, tmp_path / "out", lambda s, p: None)
    assert clips and clips[0]["transcript"] == ""
    meta = _probe(tmp_path / "out" / clips[0]["video_file"])
    video = next(s for s in meta["streams"] if s["codec_type"] == "video")
    assert (video["width"], video["height"]) == (720, 1280)
    assert (tmp_path / "out" / clips[0]["captions_file"]).read_text() == ""


def test_non_video_file_is_rejected(tmp_path):
    bad = tmp_path / "x.mp4"
    bad.write_bytes(b"not a video at all")
    import pytest
    with pytest.raises(Exception):
        processing.process_authorized_video(bad, tmp_path / "out", lambda s, p: None)
