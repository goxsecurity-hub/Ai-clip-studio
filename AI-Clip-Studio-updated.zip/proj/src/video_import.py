from __future__ import annotations

import asyncio
import re
from pathlib import Path
from urllib.parse import parse_qs, urlsplit
from uuid import uuid4

import httpx2 as httpx


_VIDEO_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")
_YOUTUBE_HOSTS = {"youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com"}


def extract_youtube_video_id(raw_url: str) -> str | None:
    """Return an ID only for supported, well-formed YouTube watch links."""
    try:
        parsed = urlsplit(raw_url.strip())
    except ValueError:
        return None

    if parsed.scheme not in {"https", "http"}:
        return None

    host = (parsed.hostname or "").lower()
    video_id = None
    if host == "youtu.be":
        video_id = parsed.path.strip("/").split("/")[0]
    elif host in _YOUTUBE_HOSTS:
        parts = [part for part in parsed.path.split("/") if part]
        if parsed.path == "/watch":
            video_id = parse_qs(parsed.query).get("v", [None])[0]
        elif len(parts) >= 2 and parts[0] in {"shorts", "embed", "live"}:
            video_id = parts[1]

    return video_id if video_id and _VIDEO_ID.fullmatch(video_id) else None


async def fetch_youtube_metadata(video_id: str) -> dict[str, str]:
    """Read public YouTube oEmbed metadata only; never retrieve the media stream."""
    video_url = f"https://www.youtube.com/watch?v={video_id}"
    async with httpx.AsyncClient(timeout=15) as client:
        response = await client.get(
            "https://www.youtube.com/oembed",
            params={"url": video_url, "format": "json"},
        )
        response.raise_for_status()
        result = response.json()

    title = result.get("title")
    thumbnail = result.get("thumbnail_url")
    if not isinstance(title, str) or not title.strip() or not isinstance(thumbnail, str):
        raise ValueError("YouTube did not provide public title and thumbnail metadata for this video.")
    return {"title": title, "thumbnail": thumbnail, "url": video_url}


async def copy_video_to_app(file, documents_dir: str, on_progress) -> Path:
    """Copy a selected local file into private app documents storage in chunks."""
    root = Path(documents_dir) / "video_uploads"
    root.mkdir(parents=True, exist_ok=True)
    original_name = Path(file.name).name or "video"
    if not Path(original_name).suffix:
        original_name += ".mp4"
    destination = root / f"{uuid4().hex[:10]}_{original_name}"
    total = file.size or 0
    copied = 0
    chunk_size = 1024 * 1024

    try:
        if file.path:
            with open(file.path, "rb") as source, destination.open("wb") as target:
                while True:
                    chunk = await asyncio.to_thread(source.read, chunk_size)
                    if not chunk:
                        break
                    await asyncio.to_thread(target.write, chunk)
                    copied += len(chunk)
                    on_progress(copied, total or copied)
                    await asyncio.sleep(0)
        elif file.bytes is not None:
            data = file.bytes
            total = len(data)
            with destination.open("wb") as target:
                for start in range(0, total, chunk_size):
                    chunk = data[start : start + chunk_size]
                    await asyncio.to_thread(target.write, chunk)
                    copied += len(chunk)
                    on_progress(copied, total)
                    await asyncio.sleep(0)
        else:
            raise OSError(
                "The picker did not provide a readable file. Try selecting the video from the Android Files app."
            )

        if copied == 0:
            raise OSError("The selected video is empty or could not be read.")
        return destination
    except Exception:
        destination.unlink(missing_ok=True)
        raise
