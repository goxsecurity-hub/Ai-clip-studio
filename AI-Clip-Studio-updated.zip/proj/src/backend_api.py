"""Authenticated client for the existing AI Clip Studio processing API."""

from __future__ import annotations

import ipaddress
import mimetypes
from pathlib import Path
import re
from urllib.parse import urlsplit

import httpx2 as httpx

MAX_UPLOAD_BYTES = 100_000_000
_JOB_ID = re.compile(r"^[a-f0-9]{32}$")


def _is_local_host(hostname: str | None) -> bool:
    """Loopback / private-LAN hosts, where plain HTTP is acceptable for local testing."""
    if not hostname:
        return False
    if hostname == "localhost":
        return True
    try:
        address = ipaddress.ip_address(hostname)
    except ValueError:
        return False
    return address.is_loopback or address.is_private


def normalize_backend_url(raw_url: str) -> str:
    """Require an explicitly supplied origin: HTTPS, or HTTP only for loopback/private-LAN testing."""
    value = raw_url.strip().rstrip("/")
    parsed = urlsplit(value)
    try:
        parsed.port  # raises ValueError on a malformed port
    except ValueError:
        raise ValueError("The backend URL has an invalid port.") from None
    if (
        parsed.scheme not in ("https", "http")
        or (parsed.scheme == "http" and not _is_local_host(parsed.hostname))
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.path not in ("", "/")
        or parsed.query
        or parsed.fragment
    ):
        raise ValueError("Enter the deployed backend's HTTPS base URL (no path, query, or secret in the URL).")
    return value


def _headers(token: str) -> dict[str, str]:
    value = token.strip()
    if not value:
        raise ValueError("Enter the backend bearer token. It is used for this session only and is not saved.")
    return {"Authorization": f"Bearer {value}"}


def _detail(response: httpx.Response) -> str:
    try:
        payload = response.json()
        detail = payload.get("detail") if isinstance(payload, dict) else None
        if isinstance(detail, str) and detail:
            return detail
        if isinstance(detail, dict):
            missing = detail.get("missing")
            if isinstance(missing, list):
                return "Backend health check failed: " + ", ".join(map(str, missing))
    except (ValueError, TypeError):
        pass
    return f"Backend request failed with HTTP {response.status_code}."


def _check(response: httpx.Response) -> httpx.Response:
    if response.is_error:
        raise RuntimeError(_detail(response))
    return response


async def submit_video(backend_url: str, token: str, video_path: str) -> dict:
    """Submit one local file to POST /v1/jobs with the required rights attestation."""
    base = normalize_backend_url(backend_url)
    headers = _headers(token)
    path = Path(video_path)
    size = path.stat().st_size
    if size <= 0:
        raise ValueError("The selected video file is empty.")
    if size > MAX_UPLOAD_BYTES:
        raise ValueError("The backend upload limit is 100 MB. Choose a smaller video.")
    content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"

    async with httpx.AsyncClient(timeout=httpx.Timeout(300, connect=20)) as client:
        with path.open("rb") as video_file:
            response = await client.post(
                f"{base}/v1/jobs",
                headers=headers,
                data={"authorized": "true"},
                files={"file": (path.name, video_file, content_type)},
            )
    payload = _check(response).json()
    job_id = payload.get("id") if isinstance(payload, dict) else None
    if not isinstance(job_id, str) or not _JOB_ID.fullmatch(job_id):
        raise RuntimeError("The backend accepted the request but returned an invalid job ID.")
    return payload


async def get_job_status(backend_url: str, token: str, job_id: str) -> dict:
    base = normalize_backend_url(backend_url)
    if not _JOB_ID.fullmatch(job_id):
        raise ValueError("The backend returned an invalid job ID.")
    async with httpx.AsyncClient(timeout=httpx.Timeout(30, connect=15)) as client:
        response = await client.get(
            f"{base}/v1/jobs/{job_id}",
            headers=_headers(token),
        )
    payload = _check(response).json()
    if not isinstance(payload, dict):
        raise RuntimeError("The backend returned an invalid job-status response.")
    return payload


def resolve_result_url(backend_url: str, result_url: str) -> str:
    """Map an API-provided clip/caption link onto the *configured* origin.

    The API returns relative paths. A same-host absolute URL is also accepted (its scheme
    is replaced by the configured one, because a TLS-terminating proxy may have reported
    http://). Any other host is rejected so the bearer token is never sent elsewhere.
    """
    base = normalize_backend_url(backend_url)
    base_parts = urlsplit(base)
    parts = urlsplit(result_url)
    if parts.username is not None or parts.password is not None:
        raise ValueError("The backend returned a download URL containing credentials.")
    if parts.scheme or parts.netloc:
        if parts.hostname != base_parts.hostname or parts.port != base_parts.port:
            raise ValueError("The backend returned a download URL outside its configured origin.")
    if not parts.path.startswith("/v1/jobs/"):
        raise ValueError("The backend returned an unexpected download path.")
    return f"{base}{parts.path}"


async def download_result(backend_url: str, token: str, result_url: str) -> bytes:
    """Download an API-provided clip/caption link, only from the configured origin."""
    url = resolve_result_url(backend_url, result_url)
    async with httpx.AsyncClient(timeout=httpx.Timeout(120, connect=15)) as client:
        response = await client.get(url, headers=_headers(token))
    return _check(response).content
