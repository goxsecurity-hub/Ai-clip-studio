import logging

import flet as ft
import httpx2 as httpx

from video_import import copy_video_to_app, extract_youtube_video_id, fetch_youtube_metadata
from views.home import build_home
from views.review import build_review

LOG_LEVEL = logging.INFO
logging.basicConfig(format="%(levelname)s %(name)s: %(message)s")
logging.getLogger("app").setLevel(LOG_LEVEL)
log = logging.getLogger("app.main")


async def main(page: ft.Page):
    page.title = "AI Clip Studio"
    page.bgcolor = ft.Colors.BLACK
    page.padding = 0
    page.theme_mode = ft.ThemeMode.DARK
    page.theme = ft.Theme(color_scheme_seed=ft.Colors.PURPLE)

    picker = ft.FilePicker()
    storage_paths = ft.StoragePaths()
    url_launcher = ft.UrlLauncher()
    refs = {}

    def show_home():
        page.clean()
        home, home_refs = build_home(upload_video, import_youtube)
        refs.clear()
        refs.update(home_refs)
        page.add(home)

    def show_review(video):
        page.clean()
        page.add(build_review(page, video, show_home, url_launcher, storage_paths, picker))

    async def upload_video():
        status = refs["upload_status"]
        progress = refs["upload_progress"]
        status.value = "Choose a video from your gallery or Files…"
        status.color = BLUE
        progress.value = None
        progress.visible = True
        page.update()
        try:
            files = await picker.pick_files(
                dialog_title="Choose a video",
                file_type=ft.FilePickerFileType.VIDEO,
                allow_multiple=False,
                # Never marshal the entire movie into the web preview's Python memory.
                # Native Android returns a readable temporary file path with this disabled.
                with_data=False,
            )
            if not files:
                progress.visible = False
                status.value = "Selection cancelled. No video was imported."
                page.update()
                return

            selected = files[0]
            log.info(
                "Video picker returned name=%r size=%d path_available=%s bytes_available=%s web=%s",
                selected.name,
                selected.size,
                bool(selected.path),
                selected.bytes is not None,
                page.web,
            )
            if page.web:
                raise OSError(
                    "The picker returned a browser file, but Flet Studio's web preview has no access "
                    "to Android's private app storage. No upload endpoint is configured. Open the "
                    "installed Android app to copy the video locally."
                )
            if not selected.path:
                raise OSError(
                    "The picker did not return a readable local file path. Choose the video from "
                    "Android Files and try again."
                )

            status.value = f"Copying {selected.name} into app storage…"
            documents_dir = await storage_paths.get_application_documents_directory()
            page.update()

            def update_progress(copied, total):
                progress.value = min(copied / total, 1) if total else None
                status.value = f"Copying {selected.name} · {copied / (1024 * 1024):.1f} / {total / (1024 * 1024):.1f} MB"
                page.update()

            stored_file = await copy_video_to_app(selected, documents_dir, update_progress)
            file_size = stored_file.stat().st_size
            progress.value = 1
            progress.visible = False
            status.value = f"Saved in app storage · {file_size / (1024 * 1024):.1f} MB"
            status.color = ft.Colors.GREEN_300
            page.update()
            show_review(
                {
                    "kind": "local",
                    "title": selected.name,
                    "path": str(stored_file),
                    "message": f"Successfully copied into this app's private video storage ({file_size / (1024 * 1024):.1f} MB).",
                }
            )
        except Exception as exc:
            log.exception("Local video import failed")
            progress.visible = False
            status.value = f"Import failed: {exc}"
            status.color = ft.Colors.ERROR
            page.update()

    async def import_youtube():
        url = refs["youtube_url"].value.strip()
        status = refs["youtube_status"]
        if not refs["rights_confirmation"].value:
            status.value = "Confirm that you own this video or have permission to use it before continuing."
            status.color = ft.Colors.ERROR
            page.update()
            return

        video_id = extract_youtube_video_id(url)
        if not video_id:
            status.value = "Enter a valid YouTube watch, youtu.be, Shorts, embed, or live video URL."
            status.color = ft.Colors.ERROR
            page.update()
            return

        status.value = "Checking public YouTube title and thumbnail…"
        status.color = BLUE
        page.update()
        try:
            metadata = await fetch_youtube_metadata(video_id)
            metadata.update(
                {
                    "kind": "youtube",
                    "message": "Metadata loaded only. No video was downloaded or copied.",
                }
            )
            show_review(metadata)
        except httpx.HTTPError as exc:
            log.exception("YouTube metadata lookup failed")
            status.value = (
                "Couldn't fetch public metadata. The link may be private/restricted, or network access "
                "may be blocked. You can upload an authorized video file instead."
            )
            status.color = ft.Colors.ERROR
            page.update()
        except Exception as exc:
            log.exception("YouTube metadata lookup failed")
            status.value = f"Couldn't read this link: {exc}"
            status.color = ft.Colors.ERROR
            page.update()

    show_home()


# Reuse the same electric-blue accent across screens without duplicating a palette module.
BLUE = ft.Colors.CYAN_300


ft.run(main)
