from __future__ import annotations

import asyncio
import logging
from pathlib import Path

import flet as ft
import flet_video as fv
import httpx2 as httpx

import backend_api

log = logging.getLogger("app.views.processing")
INK = ft.Colors.BLACK
SURFACE = ft.Colors.GREY_900
MUTED = ft.Colors.GREY_400
PURPLE = ft.Colors.PURPLE_400
BLUE = ft.Colors.CYAN_300
MAX_WAIT_SECONDS = 45 * 60


def build_processing_panel(page: ft.Page, video: dict, storage_paths, file_picker):
    backend_url = ft.TextField(
        label="Backend URL",
        hint_text="https://your-space.hf.space",
        keyboard_type=ft.KeyboardType.URL,
        autocorrect=False,
        enable_suggestions=False,
        max_lines=1,
    )
    api_token = ft.TextField(
        label="Backend bearer token (session only)",
        password=True,
        can_reveal_password=True,
        autocorrect=False,
        enable_suggestions=False,
        max_lines=1,
    )
    rights_confirmation = ft.Checkbox(
        label="I own this video or have permission to edit it.",
        value=False,
        active_color=PURPLE,
    )
    status = ft.Text(
        "Backend not connected. Enter its deployed HTTPS URL and bearer token to process this video.",
        size=12,
        color=MUTED,
        max_lines=4,
    )
    progress = ft.ProgressBar(value=None, color=BLUE, bgcolor=ft.Colors.GREY_800, visible=False)
    results = ft.Column(spacing=10, controls=[])
    preview_area = ft.Container()
    process_button = ft.Button(
        content="Find AI Highlights",
        icon=ft.Icons.AUTO_AWESOME,
        bgcolor=ft.Colors.PURPLE_700,
        color=ft.Colors.WHITE,
    )

    async def save_asset(clip: dict, asset_key: str, filename_key: str, fallback_name: str):
        target_url = clip.get(asset_key)
        if not isinstance(target_url, str) or not target_url:
            status.value = "The backend did not provide this download."
            status.color = ft.Colors.ERROR
            page.update()
            return
        try:
            status.value = "Downloading the generated file from the backend…"
            status.color = BLUE
            page.update()
            data = await backend_api.download_result(
                backend_url.value, api_token.value, target_url
            )
            filename = Path(str(clip.get(filename_key) or fallback_name)).name
            if not filename:
                filename = fallback_name
            saved_path = await file_picker.save_file(
                dialog_title="Save generated clip",
                file_name=filename,
                src_bytes=data,
            )
            status.value = "File saved." if saved_path else "Save cancelled."
            status.color = ft.Colors.GREEN_300 if saved_path else MUTED
        except (httpx.HTTPError, RuntimeError, ValueError, OSError) as exc:
            log.exception("Could not download a generated result")
            status.value = f"Download failed: {exc}"
            status.color = ft.Colors.ERROR
        page.update()

    async def preview_clip(clip: dict):
        target_url = clip.get("video_url")
        if not isinstance(target_url, str) or not target_url:
            status.value = "The backend did not provide a preview video."
            status.color = ft.Colors.ERROR
            page.update()
            return
        try:
            status.value = "Downloading the generated clip for preview…"
            status.color = BLUE
            page.update()
            data = await backend_api.download_result(
                backend_url.value, api_token.value, target_url
            )
            cache_dir = Path(await storage_paths.get_application_cache_directory())
            cache_dir.mkdir(parents=True, exist_ok=True)
            clip_name = f"ai_clip_{str(clip.get('rank', 'preview'))}.mp4"
            clip_path = cache_dir / clip_name
            await asyncio.to_thread(clip_path.write_bytes, data)
            preview_player = fv.Video(
                playlist=[fv.VideoMedia(resource=clip_path.resolve().as_uri())],
                width=180,
                height=320,
                autoplay=True,
                on_error=lambda e: show_preview_error(),
            )
            preview_area.content = ft.Container(
                width=180,
                height=320,
                border_radius=16,
                clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
                content=preview_player,
            )
            status.value = f"Previewing generated clip {clip.get('rank', '')}."
            status.color = ft.Colors.GREEN_300
        except (httpx.HTTPError, RuntimeError, ValueError, OSError) as exc:
            log.exception("Could not preview a generated clip")
            status.value = f"Preview failed: {exc}"
            status.color = ft.Colors.ERROR
        page.update()

    def show_preview_error():
        status.value = "The generated clip downloaded, but this device could not play it. Try saving the MP4 instead."
        status.color = ft.Colors.ORANGE_300
        page.update()

    def preview_handler(clip: dict):
        async def handle():
            await preview_clip(clip)
        return handle

    def download_handler(clip: dict, asset_key: str, filename_key: str, fallback_name: str):
        async def handle():
            await save_asset(clip, asset_key, filename_key, fallback_name)
        return handle

    def display_results(job: dict):
        clips = job.get("clips")
        if not isinstance(clips, list) or not clips:
            status.value = "Processing finished, but the backend returned no clips. No results were invented."
            status.color = ft.Colors.ORANGE_300
            page.update()
            return
        results.controls.clear()
        for clip in clips:
            if not isinstance(clip, dict):
                continue
            rank = clip.get("rank", len(results.controls) + 1)
            start = clip.get("start", 0)
            end = clip.get("end", 0)
            transcript = str(clip.get("transcript") or "No transcript was returned.")
            results.controls.append(
                ft.Container(
                    padding=14,
                    border_radius=16,
                    bgcolor=INK,
                    border=ft.Border.all(1, ft.Colors.with_opacity(0.18, BLUE)),
                    content=ft.Column(
                        spacing=9,
                        controls=[
                            ft.Text(f"Clip {rank} · {float(start):.1f}s–{float(end):.1f}s", color=ft.Colors.WHITE, weight=ft.FontWeight.W_600),
                            ft.Text(transcript, size=12, color=MUTED, max_lines=4),
                            ft.Row(
                                wrap=True,
                                spacing=8,
                                controls=[
                                    ft.OutlinedButton(
                                        content="Preview",
                                        icon=ft.Icons.PLAY_ARROW_ROUNDED,
                                        on_click=preview_handler(clip),
                                    ),
                                    ft.OutlinedButton(
                                        content="Save MP4",
                                        icon=ft.Icons.FILE_DOWNLOAD,
                                        on_click=download_handler(clip, "video_url", "video_file", f"highlight_{rank}.mp4"),
                                    ),
                                    *(
                                        [
                                            ft.TextButton(
                                                content="Save captions",
                                                icon=ft.Icons.FILE_DOWNLOAD,
                                                on_click=download_handler(clip, "captions_url", "captions_file", f"highlight_{rank}.srt"),
                                            )
                                        ]
                                        if clip.get("captions_url")
                                        else []
                                    ),
                                ],
                            ),
                        ],
                    ),
                )
            )
        status.value = f"Backend finished processing and returned {len(results.controls)} clip(s)."
        status.color = ft.Colors.GREEN_300
        page.update()

    async def start_processing():
        if not video.get("path"):
            status.value = "This review does not have a local video file to upload."
            status.color = ft.Colors.ERROR
            page.update()
            return
        if not rights_confirmation.value:
            status.value = "Confirm that you own this video or have permission to edit it before uploading."
            status.color = ft.Colors.ERROR
            page.update()
            return
        try:
            session_url = backend_api.normalize_backend_url(backend_url.value)
            session_token = api_token.value.strip()
            if not session_token:
                raise ValueError("Enter the backend bearer token. It is used for this session only and is not saved.")
        except ValueError as exc:
            status.value = str(exc)
            status.color = ft.Colors.ERROR
            page.update()
            return

        process_button.disabled = True
        progress.visible = True
        progress.value = None
        results.controls.clear()
        preview_area.content = None
        status.value = "Uploading the selected video to the configured backend…"
        status.color = BLUE
        page.update()
        try:
            job = await backend_api.submit_video(
                session_url,
                session_token,
                video["path"],
            )
            job_id = job["id"]
            status.value = "Upload accepted. Waiting for the real backend processing status…"
            page.update()

            failures = 0
            waited = 0
            while True:
                try:
                    job = await backend_api.get_job_status(
                        session_url,
                        session_token,
                        job_id,
                    )
                    failures = 0
                except httpx.TransportError:
                    # Server-side processing continues if the phone briefly loses signal.
                    failures += 1
                    if failures > 15:
                        raise
                    status.value = f"Connection lost, retrying ({failures}/15)…"
                    status.color = ft.Colors.ORANGE_300
                    page.update()
                    await asyncio.sleep(4)
                    waited += 4
                    continue
                status.color = BLUE
                raw_progress = job.get("progress")
                if isinstance(raw_progress, (int, float)):
                    progress.value = max(0.0, min(1.0, float(raw_progress) / 100.0))
                stage = str(job.get("stage") or job.get("state") or "Processing")
                percent = f" · {int(raw_progress)}%" if isinstance(raw_progress, (int, float)) else ""
                status.value = f"{stage}{percent}"
                state = job.get("state")
                page.update()
                if state == "complete":
                    progress.value = 1
                    display_results(job)
                    break
                if state == "failed":
                    error = str(job.get("error") or "The backend reported a processing failure.")
                    status.value = f"Processing failed: {error}"
                    status.color = ft.Colors.ERROR
                    break
                await asyncio.sleep(2)
                waited += 2
                if waited > MAX_WAIT_SECONDS:
                    raise RuntimeError("Processing is taking too long (over 45 minutes). It may still finish on the server.")
        except (httpx.HTTPError, RuntimeError, ValueError, OSError, KeyError) as exc:
            log.exception("Backend upload or processing request failed")
            status.value = f"Backend request failed: {exc}"
            status.color = ft.Colors.ERROR
        finally:
            progress.visible = False
            process_button.disabled = False
            page.update()

    process_button.on_click = start_processing

    return ft.Container(
        padding=16,
        border_radius=18,
        bgcolor=SURFACE,
        content=ft.Column(
            spacing=11,
            controls=[
                ft.Text("Process with AI", size=16, weight=ft.FontWeight.W_600, color=ft.Colors.WHITE),
                ft.Text("Connect to your deployed backend. URL and token are not saved. The current backend uses one shared token; do not distribute it in a public app.", size=11, color=MUTED),
                backend_url,
                api_token,
                rights_confirmation,
                process_button,
                progress,
                status,
                preview_area,
                results,
            ],
        ),
    )
