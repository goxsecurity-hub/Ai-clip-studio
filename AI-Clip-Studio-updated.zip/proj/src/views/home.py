from __future__ import annotations

import flet as ft

INK = ft.Colors.BLACK
SURFACE = ft.Colors.GREY_900
MUTED = ft.Colors.GREY_400
PURPLE = ft.Colors.PURPLE_400
BLUE = ft.Colors.CYAN_300


def build_home(on_upload, on_youtube_import):
    upload_status = ft.Text("", size=12, color=BLUE, max_lines=2)
    upload_progress = ft.ProgressBar(value=None, color=BLUE, bgcolor=ft.Colors.GREY_800, visible=False)
    youtube_url = ft.TextField(
        label="YouTube video URL",
        hint_text="https://www.youtube.com/watch?v=…",
        keyboard_type=ft.KeyboardType.URL,
        autocorrect=False,
        enable_suggestions=False,
        max_lines=1,
    )
    rights_confirmation = ft.Checkbox(
        label="I own this video or have permission to use it.",
        value=False,
        active_color=PURPLE,
    )
    youtube_status = ft.Text("", size=12, color=MUTED, max_lines=3)
    upload_button = None
    youtube_button = None

    def section_heading(title: str, trailing: str = ""):
        items = [ft.Text(title, size=19, weight=ft.FontWeight.W_600, color=ft.Colors.WHITE)]
        if trailing:
            items.append(ft.Text(trailing, size=12, color=MUTED))
        return ft.Row(controls=items, alignment=ft.MainAxisAlignment.SPACE_BETWEEN)

    upload_card = ft.Container(
        padding=20,
        border_radius=22,
        bgcolor=SURFACE,
        border=ft.Border.all(1, ft.Colors.with_opacity(0.22, PURPLE)),
        content=ft.Column(
            spacing=14,
            controls=[
                ft.Row(
                    spacing=12,
                    controls=[
                        ft.Container(
                            width=48,
                            height=48,
                            alignment=ft.Alignment.CENTER,
                            border_radius=16,
                            bgcolor=ft.Colors.with_opacity(0.16, PURPLE),
                            content=ft.Icon(ft.Icons.VIDEO_FILE, color=PURPLE, size=25),
                        ),
                        ft.Column(
                            spacing=4,
                            expand=True,
                            controls=[
                                ft.Text("Create something cinematic", size=16, weight=ft.FontWeight.W_600, color=ft.Colors.WHITE),
                                ft.Text("Choose a video from your device", size=12, color=MUTED),
                            ],
                        ),
                    ],
                ),
                ft.Button(
                    content=ft.Row(
                        tight=True,
                        spacing=9,
                        alignment=ft.MainAxisAlignment.CENTER,
                        controls=[
                            ft.Icon(ft.Icons.CLOUD_UPLOAD_OUTLINED, size=20),
                            ft.Text("Upload Your Video", size=15, weight=ft.FontWeight.W_600),
                        ],
                    ),
                    on_click=on_upload,
                    bgcolor=ft.Colors.PURPLE_700,
                    color=ft.Colors.WHITE,
                    style=ft.ButtonStyle(padding=ft.Padding.symmetric(vertical=15, horizontal=18)),
                ),
                upload_progress,
                upload_status,
            ],
        ),
    )

    youtube_card = ft.Container(
        padding=18,
        border_radius=20,
        bgcolor=SURFACE,
        content=ft.Column(
            spacing=12,
            controls=[
                ft.Row(
                    spacing=10,
                    controls=[
                        ft.Icon(ft.Icons.LINK, color=BLUE, size=21),
                        ft.Text("Import from YouTube", size=16, weight=ft.FontWeight.W_600, color=ft.Colors.WHITE),
                    ],
                ),
                youtube_url,
                rights_confirmation,
                ft.Text(
                    "YouTube links show public title and thumbnail only. The video stays on YouTube; no video is downloaded. For editing, upload an authorized video file from your device.",
                    size=11,
                    color=MUTED,
                ),
                ft.Button(
                    content="Import YouTube Video",
                    on_click=on_youtube_import,
                    bgcolor=ft.Colors.BLUE_900,
                    color=ft.Colors.WHITE,
                ),
                youtube_status,
            ],
        ),
    )

    highlights_card = ft.Container(
        padding=16,
        border_radius=18,
        bgcolor=ft.Colors.with_opacity(0.10, BLUE),
        border=ft.Border.all(1, ft.Colors.with_opacity(0.16, BLUE)),
        content=ft.Row(
            spacing=13,
            controls=[
                ft.Container(
                    width=42,
                    height=42,
                    alignment=ft.Alignment.CENTER,
                    border_radius=14,
                    bgcolor=ft.Colors.with_opacity(0.16, BLUE),
                    content=ft.Icon(ft.Icons.AUTO_AWESOME, color=BLUE, size=22),
                ),
                ft.Column(
                    spacing=4,
                    expand=True,
                    controls=[
                        ft.Text("Your next great moment", size=14, weight=ft.FontWeight.W_600, color=ft.Colors.WHITE),
                        ft.Text("Import a video to review its source details.", size=12, color=MUTED),
                    ],
                ),
            ],
        ),
    )

    projects_card = ft.Container(
        padding=18,
        border_radius=18,
        bgcolor=SURFACE,
        content=ft.Row(
            spacing=12,
            controls=[
                ft.Icon(ft.Icons.VIDEO_LIBRARY_OUTLINED, color=ft.Colors.GREY_600, size=25),
                ft.Column(
                    spacing=4,
                    expand=True,
                    controls=[
                        ft.Text("No projects yet", size=14, weight=ft.FontWeight.W_600, color=ft.Colors.WHITE),
                        ft.Text("Your recent work will appear here.", size=12, color=MUTED),
                    ],
                ),
            ],
        ),
    )

    content = ft.Column(
        expand=True,
        spacing=0,
        controls=[
            ft.ListView(
                expand=True,
                spacing=22,
                padding=ft.Padding.only(left=20, top=18, right=20, bottom=18),
                controls=[
                    ft.Row(
                        spacing=11,
                        controls=[
                            ft.Container(
                                width=38,
                                height=38,
                                alignment=ft.Alignment.CENTER,
                                border_radius=13,
                                bgcolor=ft.Colors.with_opacity(0.16, PURPLE),
                                content=ft.Icon(ft.Icons.PLAY_ARROW_ROUNDED, color=BLUE, size=24),
                            ),
                            ft.Column(
                                spacing=1,
                                controls=[
                                    ft.Text("AI Clip Studio", size=20, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE),
                                    ft.Text("Your creative space", size=11, color=MUTED),
                                ],
                            ),
                            ft.Container(expand=True),
                            ft.Icon(ft.Icons.AUTO_AWESOME, color=PURPLE, size=21),
                        ],
                    ),
                    upload_card,
                    youtube_card,
                    ft.Column(spacing=12, controls=[section_heading("AI Highlights"), highlights_card]),
                    ft.Column(spacing=12, controls=[section_heading("Your Recent Projects", "View all"), projects_card]),
                ],
            ),
            ft.Container(
                padding=ft.Padding.only(left=24, top=10, right=24, bottom=8),
                border=ft.Border.only(top=ft.BorderSide(1, ft.Colors.GREY_900)),
                bgcolor=INK,
                content=ft.Row(
                    alignment=ft.MainAxisAlignment.SPACE_AROUND,
                    controls=[
                        nav_item(ft.Icons.HOME_ROUNDED, "Home", True),
                        nav_item(ft.Icons.VIDEO_LIBRARY_OUTLINED, "Projects"),
                        nav_item(ft.Icons.PERSON_OUTLINE, "Profile"),
                    ],
                ),
            ),
        ],
    )

    return ft.SafeArea(expand=True, content=content), {
        "upload_status": upload_status,
        "upload_progress": upload_progress,
        "youtube_url": youtube_url,
        "rights_confirmation": rights_confirmation,
        "youtube_status": youtube_status,
    }


def nav_item(icon, label: str, active: bool = False):
    color = PURPLE if active else ft.Colors.GREY_600
    return ft.Column(
        tight=True,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=4,
        controls=[ft.Icon(icon, color=color, size=21), ft.Text(label, size=10, color=color)],
    )
