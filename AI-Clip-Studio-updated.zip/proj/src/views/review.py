from __future__ import annotations

from pathlib import Path

import flet as ft
import flet_video as fv

from views.processing import build_processing_panel

INK = ft.Colors.BLACK
SURFACE = ft.Colors.GREY_900
MUTED = ft.Colors.GREY_400
PURPLE = ft.Colors.PURPLE_400
BLUE = ft.Colors.CYAN_300


def build_review(page: ft.Page, video: dict, on_back, url_launcher, storage_paths, file_picker):
    duration_text = ft.Text("Reading duration…", size=12, color=MUTED)
    message = ft.Text(video.get("message", ""), size=12, color=ft.Colors.GREEN_300)
    thumbnail = ft.Image(
        src=video.get("thumbnail", ""),
        width=320,
        height=190,
        fit=ft.BoxFit.COVER,
        border_radius=16,
        error_content=ft.Container(
            width=320,
            height=190,
            alignment=ft.Alignment.CENTER,
            bgcolor=SURFACE,
            content=ft.Icon(ft.Icons.VIDEO_FILE, size=44, color=BLUE),
        ),
    )
    local_thumbnail = ft.Image(
        src="",
        width=96,
        height=60,
        fit=ft.BoxFit.COVER,
        border_radius=10,
        error_content=ft.Container(
            width=96,
            height=60,
            alignment=ft.Alignment.CENTER,
            bgcolor=INK,
            content=ft.Icon(ft.Icons.VIDEO_FILE, size=22, color=BLUE),
        ),
    )
    player = None

    if video.get("kind") == "local":
        file_uri = Path(video["path"]).resolve().as_uri()

        async def refresh_duration(_event=None):
            try:
                duration = await player.get_duration()
                if duration and duration.in_seconds > 0:
                    total = duration.in_seconds
                    duration_text.value = f"Duration · {total // 60}:{total % 60:02d}"
                    page.update()
            except Exception:
                duration_text.value = "Duration unavailable for this file."
                page.update()

        async def capture_thumbnail(_event=None):
            try:
                frame = await player.take_screenshot()
                if frame:
                    local_thumbnail.src = frame
                    local_thumbnail.error_content = None
                    local_thumbnail.update()
            except Exception:
                # Keep the neutral video icon if the platform player cannot capture a frame.
                pass
            await refresh_duration()

        def player_error(_event):
            message.value = (
                "The video was copied into app storage, but this device could not preview it. "
                "Try an MP4 video encoded with H.264/AAC."
            )
            message.color = ft.Colors.ORANGE_300
            page.update()

        player = fv.Video(
            playlist=[fv.VideoMedia(resource=file_uri)],
            width=320,
            height=190,
            autoplay=False,
            on_load=capture_thumbnail,
            on_duration_change=refresh_duration,
            on_error=player_error,
        )
        media_content = ft.Container(
            width=320,
            height=190,
            border_radius=16,
            clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
            content=player,
        )
        thumbnail.visible = False
    else:
        media_content = thumbnail
        duration_text.value = "YouTube preview · video remains hosted by YouTube"

    async def open_youtube():
        try:
            await url_launcher.launch_url(video["url"])
        except Exception:
            message.value = "Couldn't open YouTube. Copy the link and open it in your browser."
            message.color = ft.Colors.ORANGE_300
            page.update()

    details_controls = [
        ft.Text(video["title"], size=19, weight=ft.FontWeight.W_600, color=ft.Colors.WHITE),
        *(
            [ft.Row(spacing=12, controls=[local_thumbnail, duration_text])]
            if video.get("kind") == "local"
            else [duration_text]
        ),
        message,
    ]
    if video.get("kind") == "youtube":
        details_controls.extend(
            [
                ft.Text(
                    "This import contains link metadata only—not a video file. To review/edit the video inside the app, use Upload Your Video with a copy you own or are authorized to use.",
                    size=12,
                    color=MUTED,
                ),
                ft.Button(
                    content="Open on YouTube",
                    icon=ft.Icons.OPEN_IN_NEW,
                    bgcolor=ft.Colors.BLUE_900,
                    color=ft.Colors.WHITE,
                    on_click=open_youtube,
                ),
            ]
        )

    screen = ft.Column(
        expand=True,
        spacing=18,
        controls=[
            ft.Row(
                controls=[
                    ft.IconButton(ft.Icons.ARROW_BACK, icon_color=ft.Colors.WHITE, on_click=on_back),
                    ft.Text("Video review", size=20, weight=ft.FontWeight.W_600, color=ft.Colors.WHITE),
                ],
            ),
            ft.ListView(
                expand=True,
                spacing=16,
                padding=ft.Padding.only(left=20, right=20, bottom=24),
                controls=[
                    ft.Container(
                        padding=12,
                        border_radius=20,
                        bgcolor=SURFACE,
                        content=ft.Column(
                            spacing=14,
                            controls=[
                                ft.Container(alignment=ft.Alignment.CENTER, content=media_content),
                                ft.Column(spacing=8, controls=details_controls),
                                *(
                                    [build_processing_panel(page, video, storage_paths, file_picker)]
                                    if video.get("kind") == "local"
                                    else []
                                ),
                            ],
                        ),
                    ),
                ],
            ),
        ],
    )
    return ft.SafeArea(expand=True, content=screen)
